{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "step-certificates.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "step-certificates.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "step-certificates.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "step-certificates.labels" -}}
helm.sh/chart: {{ include "step-certificates.chart" . }}
app.kubernetes.io/name: {{ include "step-certificates.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Create CA URL
*/}}
{{- define "step-certificates.url" -}}
{{- if .Values.ca.url -}}
{{- .Values.ca.url -}}
{{- else -}}
{{- printf "https://%s.%s.svc.cluster.local" (include "step-certificates.fullname" .) .Release.Namespace -}}
{{- end -}}
{{- end -}}

{{/*
Create CA DNS
*/}}
{{- define "step-certificates.dns" -}}
{{- if .Values.ca.dns -}}
{{- .Values.ca.dns -}}
{{- else -}}
{{- printf "%s.%s.svc.cluster.local,127.0.0.1" (include "step-certificates.fullname" .) .Release.Namespace -}}
{{- end -}}
{{- end -}}

{{/*
Linked CA variables
*/}}
{{- define "step-certificates.linkedca.secretKeyRef.name" -}}
{{- if .Values.linkedca.secretKeyRef.name -}}
{{- .Values.linkedca.secretKeyRef.name -}}
{{- else -}}
{{- printf "%s-step-ca-token" (include "step-certificates.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "step-certificates.linkedca.secretKeyRef.key" -}}
{{- if .Values.linkedca.secretKeyRef.key -}}
{{- .Values.linkedca.secretKeyRef.key -}}
{{- else -}}
token
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "step-certificates.serviceaccountname" -}}
{{- if .Values.serviceaccount.create -}}
    {{ default (include "step-certificates.fullname" .) .Values.serviceaccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceaccount.name }}
{{- end -}}
{{- end -}}


{{/* stepca-ui helpers */}}
{{- define "step-certificates.ui.fullname" -}}
{{- printf "%s-ui" (include "step-certificates.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "step-certificates.ui.labels" -}}
helm.sh/chart: {{ include "step-certificates.chart" . }}
app.kubernetes.io/name: stepca-ui
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: ui
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "step-certificates.ui.selectorLabels" -}}
app.kubernetes.io/name: stepca-ui
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/* profile names, default profile first, then alphabetical */}}
{{- define "step-certificates.ui.profileNames" -}}
{{- $names := keys .Values.ui.profiles | sortAlpha -}}
{{- $def := .Values.ui.defaultProfile -}}
{{- $out := list -}}
{{- if and $def (hasKey .Values.ui.profiles $def) }}{{ $out = append $out $def }}{{ end -}}
{{- range $names }}{{ if ne . $def }}{{ $out = append $out . }}{{ end }}{{ end -}}
{{- join "," $out -}}
{{- end -}}
